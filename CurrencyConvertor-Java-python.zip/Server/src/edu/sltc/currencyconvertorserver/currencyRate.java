package edu.sltc.currencyconvertorserver;


import edu.sltc.currencyconvertorserver.res.currenciesData;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class currencyRate {
    private String sourceCurrency; //make string to store source currency.
    private String targetCurrency; //make string to store target currency.
    private static final HashMap<String,Double> RATE_LIST = new HashMap<>(); //make HashMap to store currency names vs rates.

    public currencyRate(String firstCurrency, String secondCurrency) { // make constructor.
        this.sourceCurrency = firstCurrency;
        this.targetCurrency = secondCurrency;
        List<String> tempNames = new ArrayList<>(Arrays.asList(currenciesData.names.split(","))); //Split the single String as a list of names.
        List<String> tempRates = new ArrayList<>(Arrays.asList(currenciesData.rates.split(","))); //Split the single String as a list of rates.
        int i =0;
        while (i<tempNames.size()) {
            RATE_LIST.put(tempNames.get(i), Double.parseDouble(tempRates.get(i)));
            i++;
        }
    }

    public Double convert(double sourceAmount){
        return sourceAmount * RATE_LIST.get(targetCurrency) / RATE_LIST.get(sourceCurrency);
    }

}
