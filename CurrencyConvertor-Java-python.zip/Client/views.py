
import json
import os
import zeep

from flask import Blueprint, render_template, request

views = Blueprint(__name__, "view")
client = zeep.Client('http://localhost:8888/SoapWebService?wsdl')


@views.route("/", methods=['GET', 'POST'])
def home():
    currency = currency_data()
    currency = {value: key for key, value in currency.items()}
    lable = list(currency.keys())
    sourceCurrency = lable[85]
    targetCurrency = lable[149]
    first_amount = None
    second_amount = 0.00
    if request.method == 'POST':
        first_amount = request.form['first_amount']
        sourceCurrency = request.form['selectedFirstCurrency']
        targetCurrency = request.form['selectedSecondCurrency']
        # print(currency.get(sourceCurrency), first_amount, targetCurrency)
        second_amount = client.service.convert(currency.get(sourceCurrency),currency.get(targetCurrency),first_amount)
    return render_template("index.html", firstAmount=first_amount, secondAmount=second_amount, currencyList=lable, sourceCurrency=sourceCurrency, targetCurrency=targetCurrency)


def currency_data():
    """ All countries' currency data """
    module_dir = os.path.dirname(__file__)  # get current directory
    file_path = os.path.join(module_dir, 'res', 'currencies.json')
    with open(file_path, "r") as f:
        currency_data_dict = json.loads(f.read())
    return currency_data_dict




